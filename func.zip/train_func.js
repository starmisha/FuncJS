/* Задание 1*/
/* Под чётными элементами массива имеются ввиду чётные числа и всё?*/
function sortArrayElements(array) {
	let evens = array.filter(item => item % 2 === 0 && item !== 0 && typeof item === 'number' && item !== NaN);
	let odds = array.filter(item => item % 2 !== 0 && typeof item === 'number' && item !== NaN);
	let zeros = array.filter(item => item === 0);

	console.log('Кол-во чётных элементов:', evens.length);
	console.log('Кол-во нечётных элементов:', odds.length);
	console.log('нулевой элемент:', zeros);
}
sortArrayElements([null, 8, 3, 3, 5, 13, 24, 0])



/* PЗадание 2 */

function isPrime(num) {
	if (num > 1000) {
		return 'Данные неверны. Число должно быть меньше или равно 1000.';
	}

	if (num <= 1) {
		return false;
	}

	for (let i = 2; i * i <= num; i++) {
		if (num % i === 0) {
			return 'Число составное'
		}
	}

	return 'Число простое'
}
console.log(isPrime(17))
/*Задание 3 */

function createAdder(x) {
	return function (y) {
		return x + y;
	};
}
let addTWo = createAdder(10)
console.log(addTWo(2))

/* Задание 4*/

function printNumbersWithDelay(start, end) {
	let current = start;
	const intervalId = setInterval(function () {
		console.log(current);
		if (current >= end) {
			clearInterval(intervalId);
		}
		current++;
	}, 1000);
}

printNumbersWithDelay(1, 18);
/* Можно и через setTimeout()
function printNumbersWithDelay(start, end) {
setTimeout(() => {
	 console.log(start);
	 if (start < end) {
		  printNumbersWithDelay(start + 1, end);
	 }
}, 1000 * (start - (start - 1))); // задержка в 1 секунду
}

printNumbersWithDelay(1, 10);*/

/* Задание 5 */

const pow = (x, n) => {
	let result = 1;
	for (let i = 0; i < n; i++) {
		result *= x;
	}
	return result;
};
console.log(pow(2, 10))

/* Попробуйте сами*/

// Создаем пустой объект
let myObject = {};



// Добавляем свойства
myObject.name = "Test Object";    // Строка
myObject.age = 25;                // Число
myObject.isMarried = false;       // Булево значение
myObject.children = ["John", "Jane"];   // Массив
myObject.nullProp = null;         // Null
myObject.undefinedProp = undefined;    // Undefined

// Добавляем метод
myObject.sayHello = function () {
	console.log("Привет!");
};

// Проверка объекта
console.log(myObject);

// Удаление свойства
delete myObject.age;

// Проверка объекта после удаления свойства
console.log(myObject);